from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
	return render_template('index.html')

@app.route('/raspored')
def raspored():
	f = open("raspored.csv", "r")
	redovi = f.readlines()
	imena_profesora = [red.split(',')[2] for red in redovi]
	jedinstveno_ime = []
	for ime in imena_profesora:
		if ime not in jedinstveno_ime:
			jedinstveno_ime.append(ime)

	ucionice = [red.split(',')[6] for red in redovi]
	jedinstvena_ucionica = []
	for ucionica in ucionice:
		if ucionica not in jedinstvena_ucionica:
			jedinstvena_ucionica.append(ucionica)

	return render_template("raspored.html", redovi = redovi, jedinstveno_ime = jedinstveno_ime, jedinstvena_ucionica = jedinstvena_ucionica)


if __name__ == '__main__':
	app.run()